// NodeJs Document

var mysql = require('mysql');
var express = require('express');
var http = require('http');
var path = require('path');

var app = express();
var bodyParser = require('body-parser');
var urlencodedParser = bodyParser.urlencoded({ extended: false });

app.use(bodyParser.json());

app.use(bodyParser.urlencoded({
	extended: true
}));
var conn = mysql.createConnection({
	host: "localhost",
	user : "root",
	password: "",
	database: "WeFarm"
});
app.get('/',function(req,res){
  res.sendFile(path.join(__dirname+'/farmer-signup.html'));
});
app.post('/farmer-signup.html', function(req, res){
	
	var name = req.body.name;
	var phone = req.body.Phone_no;
	var state = req.body.state;
	var city = req.body.city;
	var pass = req.body.password;
	
	res.write('You sent the name "' + req.body.name+'" .\n');
	res.write('You sent the name "' + req.body.phone+'" .\n');
	
	conn.connect(function(err){
		if(err) throw err;
		console.log("Connected !");
		
		var sql = "INSERT INTO farmer (name, Phone_no, state, city, password, rating) VALUES ('"+name+"', '+phone+','"+state+"','"+city+"','"+pass+"',5)";
		
		conn.query(sql, function(err,result){
			if(err) {throw "unable to process query";
			console.log(err);
					}
			
			console.log("1 record Inserted");
			res.end();
		})
	})
});
app.listen(3000);
console.log("Running on Port 3000");
